import React, { useState } from 'react';
import { AlertTriangle, PhoneCall, Heart, MapPin, CheckCircle, ShieldAlert, X, Volume2, UserCheck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  cityName: string;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({ isOpen, onClose, cityName }) => {
  const { t } = useLanguage();
  const [alertSent, setAlertSent] = useState(false);
  const [sirenPlaying, setSirenPlaying] = useState(false);

  if (!isOpen) return null;

  const triggerSiren = () => {
    try {
      if ('AudioContext' in window || 'webkitAudioContext' in window) {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.4);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.8);
      }
    } catch {
      // Audio fallback
    }
    setSirenPlaying(true);
    setTimeout(() => setSirenPlaying(false), 1200);
  };

  const handleNotifyFamily = () => {
    setAlertSent(true);
  };

  return (
    <div 
      id="emergencyModalBackdrop"
      role="dialog" 
      aria-modal="true" 
      aria-labelledby="emergencyTitle" 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full max-h-[92vh] overflow-y-auto p-5 sm:p-6 md:p-8 shadow-2xl border-4 border-red-600 relative text-slate-900 dark:text-slate-100 transition-colors">
        {/* Urgent header tag */}
        <div className="bg-red-600 -mx-5 sm:-mx-6 md:-mx-8 -mt-5 sm:-mt-6 md:-mt-8 p-4 text-white flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-xl animate-pulse">
              <AlertTriangle className="h-7 w-7 text-yellow-300" />
            </div>
            <div>
              <h2 id="emergencyTitle" className="text-xl md:text-2xl font-black tracking-wide">{t.emergencyTitle}</h2>
              <p className="text-xs md:text-sm text-red-100 font-medium">{t.emergencySubtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/20 p-2 rounded-full transition cursor-pointer"
            aria-label="Close emergency modal"
            id="closeEmergencyModal"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="mt-6 space-y-4">
          {/* Quick 1-Tap Ambulance Call */}
          <div className="bg-red-50 dark:bg-red-950/40 border-2 border-red-200 dark:border-red-900/60 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-center sm:text-left">
              <div className="text-sm font-bold text-red-700 dark:text-red-400 uppercase tracking-wider">National 24x7 Ambulance</div>
              <div className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">Dial 108 / 102</div>
              <div className="text-xs text-slate-600 dark:text-slate-400 flex items-center justify-center sm:justify-start gap-1 mt-0.5">
                <MapPin className="h-3.5 w-3.5 text-red-600 dark:text-red-400" /> {t.ambulanceSub} ({cityName})
              </div>
            </div>
            <a
              href="tel:108"
              id="callAmbulanceBtn"
              className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white font-black px-6 py-3.5 rounded-2xl text-lg flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 transition transform active:scale-95 cursor-pointer"
            >
              <PhoneCall className="h-6 w-6" /> {t.sosCallAmbulance}
            </a>
          </div>

          {/* KinCare Doctor Helpline */}
          <div className="bg-teal-50 dark:bg-teal-950/40 border-2 border-teal-200 dark:border-teal-800/60 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-center sm:text-left">
              <div className="text-sm font-bold text-teal-800 dark:text-teal-300 uppercase tracking-wider">{t.doctorHelplineTitle}</div>
              <div className="text-xl md:text-2xl font-black text-slate-900 dark:text-white">1800-123-4567</div>
              <div className="text-xs text-slate-600 dark:text-slate-400">{t.doctorHelplineSub}</div>
            </div>
            <a
              href="tel:18001234567"
              id="callDoctorHelplineBtn"
              className="w-full sm:w-auto bg-teal-700 hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500 text-white font-bold px-5 py-3 rounded-2xl flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
            >
              <PhoneCall className="h-5 w-5" /> {t.callDoctor}
            </a>
          </div>

          {/* Emergency Alert Dispatch */}
          <div className="border-2 border-slate-200 dark:border-slate-700 rounded-2xl p-4 bg-slate-50 dark:bg-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 dark:text-white text-sm md:text-base flex items-center gap-2">
                <ShieldAlert className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                Emergency Contact Broadcast
              </span>
              <button
                type="button"
                onClick={triggerSiren}
                id="emergencySirenBtn"
                className={`text-xs px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                  sirenPlaying ? 'bg-red-600 text-white animate-bounce' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'
                }`}
              >
                <Volume2 className="h-4 w-4" /> {sirenPlaying ? t.beeping : t.soundSiren}
              </button>
            </div>

            <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300">
              {t.alertDesc}
            </p>

            {alertSent ? (
              <div className="p-3 bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700 rounded-xl text-emerald-900 dark:text-emerald-300 font-bold text-sm flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                <span>{t.alertSentMessage}</span>
              </div>
            ) : (
              <button
                onClick={handleNotifyFamily}
                id="sendEmergencyAlertBtn"
                className="w-full bg-slate-900 hover:bg-slate-800 dark:bg-teal-600 dark:hover:bg-teal-500 text-white font-extrabold py-3 rounded-xl transition flex items-center justify-center gap-2 shadow cursor-pointer"
              >
                <UserCheck className="h-5 w-5 text-teal-400 dark:text-white" /> {t.notifyFamilyBtn}
              </button>
            )}
          </div>

          {/* Senior Emergency Medical Quick Card */}
          <div className="p-3.5 bg-amber-50/70 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 rounded-xl text-xs text-amber-950 dark:text-amber-200 flex items-start gap-2.5">
            <Heart className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-black block text-sm">{t.quickMedicalCard}</span>
              <p className="text-slate-700 dark:text-slate-300 mt-0.5">
                Blood Group: <strong className="text-slate-900 dark:text-white">O+ Positive</strong> | Allergies: <strong className="text-slate-900 dark:text-white">Penicillin</strong> | Conditions: <strong className="text-slate-900 dark:text-white">Hypertension, Pacemaker (2022)</strong>
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={onClose}
            id="dismissEmergencyBtn"
            className="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-bold text-sm py-2 px-6 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            {t.closeEmergency}
          </button>
        </div>
      </div>
    </div>
  );
};
