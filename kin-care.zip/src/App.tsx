/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  PhoneOutgoing, 
  ShieldCheck, 
  HeartHandshake, 
  CheckCircle2, 
  Sparkles,
  Headphones
} from 'lucide-react';
import { CareService, Booking, ServiceCategory } from './types';
import { SERVICES_DATA, INITIAL_BOOKINGS } from './data/servicesData';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { ServiceCard } from './components/ServiceCard';
import { BookingModal } from './components/BookingModal';
import { EmergencyModal } from './components/EmergencyModal';
import { EmergencySOSBanner } from './components/EmergencySOSBanner';
import { BookingsDrawer } from './components/BookingsDrawer';
import { CallSupportModal } from './components/CallSupportModal';
import { LanguageModal } from './components/LanguageModal';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { ProfilePage } from './components/ProfilePage';
import { MobileBottomNav } from './components/MobileBottomNav';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';

function KinCareApp() {
  const { t } = useLanguage();
  const [selectedCity, setSelectedCity] = useState<string>('South Extension, Delhi');
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory>('all');
  
  // Bookings with local storage backup
  const [bookings, setBookings] = useState<Booking[]>(() => {
    try {
      const saved = localStorage.getItem('kincare_bookings') || localStorage.getItem('silvercare_bookings');
      return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
    } catch {
      return INITIAL_BOOKINGS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('kincare_bookings', JSON.stringify(bookings));
    } catch {
      // Storage fallback
    }
  }, [bookings]);

  // Check if current URL is requesting dedicated profile view (e.g. ?view=profile or #profile)
  const [isProfileView, setIsProfileView] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const params = new URLSearchParams(window.location.search);
    return params.get('view') === 'profile' || window.location.hash === '#profile';
  });

  useEffect(() => {
    const handleLocationChange = () => {
      const params = new URLSearchParams(window.location.search);
      setIsProfileView(params.get('view') === 'profile' || window.location.hash === '#profile');
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const handleOpenProfileInNewTab = () => {
    const profileUrl = `${window.location.origin}${window.location.pathname}?view=profile`;
    window.open(profileUrl, '_blank', 'noopener,noreferrer');
  };

  // Modals state
  const [bookingService, setBookingService] = useState<CareService | null>(null);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isCallSupportOpen, setIsCallSupportOpen] = useState(false);
  const [isBookingsOpen, setIsBookingsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [callSupportContext, setCallSupportContext] = useState<string | undefined>(undefined);

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleBookService = (service: CareService) => {
    setBookingService(service);
  };

  const handleQuickCall = (service: CareService) => {
    setCallSupportContext(service.title);
    setIsCallSupportOpen(true);
  };

  const handleBookingSuccess = (newBooking: Booking) => {
    setBookings((prev) => [newBooking, ...prev]);
    showToast(`Visit for ${newBooking.serviceTitle} confirmed for ${newBooking.patientName}!`);
  };

  const handleCancelBooking = (bookingId: string) => {
    setBookings((prev) => prev.filter((b) => b.id !== bookingId));
    showToast('Visit cancelled successfully.');
  };

  // Filtered services
  const filteredServices = SERVICES_DATA.filter((service) => {
    if (selectedCategory === 'all') return true;
    return service.category === selectedCategory;
  });

  if (isProfileView) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-teal-200 transition-colors">
        <ProfilePage
          onBackToHome={() => {
            const url = new URL(window.location.href);
            url.searchParams.delete('view');
            url.hash = '';
            window.history.pushState({}, '', url.pathname + (url.search ? url.search : ''));
            setIsProfileView(false);
          }}
          bookings={bookings}
          onCancelBooking={handleCancelBooking}
        />
        <AuthModal />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-teal-200 transition-colors">
      {/* Toast Notification */}
      {toastMessage && (
        <div 
          role="status"
          aria-live="polite"
          className="fixed bottom-6 right-6 z-50 bg-slate-900 dark:bg-slate-800 text-white font-bold px-5 py-3 rounded-2xl shadow-2xl border-2 border-teal-500 flex items-center gap-3 animate-fade-in text-sm md:text-base"
        >
          <CheckCircle2 className="h-5 w-5 text-teal-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navigation and Urgent SOS */}
      <Navbar
        selectedCity={selectedCity}
        onCityChange={setSelectedCity}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenBookings={() => setIsBookingsOpen(true)}
        onOpenCallHelp={() => {
          setCallSupportContext('Senior Care Inquiries');
          setIsCallSupportOpen(true);
        }}
        onOpenProfile={handleOpenProfileInNewTab}
        bookingsCount={bookings.length}
      />

      {/* Hero Banner */}
      <HeroBanner
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        onOpenCallHelp={() => {
          setCallSupportContext('General Assistance');
          setIsCallSupportOpen(true);
        }}
        cityName={selectedCity}
      />

      {/* Main Services Grid */}
      <main className="max-w-7xl mx-auto px-4 pb-16 flex-1 w-full">
        <div className="mb-6 flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h2 className="text-2xl md:text-3xl font-black tracking-tight text-slate-900 dark:text-white">
              {t.chooseService}
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-sm md:text-base mt-1">
              {t.chooseServiceSub} <strong className="text-slate-900 dark:text-white">{selectedCity}</strong>.
            </p>
          </div>
          <span className="text-xs font-bold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/80 px-3 py-1.5 rounded-full border border-teal-200 dark:border-teal-800">
            {filteredServices.length} {t.chooseService}
          </span>
        </div>

        {/* Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredServices.map((service) => (
            <ServiceCard
              key={service.id}
              service={service}
              onBook={handleBookService}
              onQuickCall={handleQuickCall}
            />
          ))}

          {/* Quick Call Assistance Card */}
          <div 
            id="phoneBookingCard"
            className="bg-teal-50/80 dark:bg-teal-950/40 border-2 border-dashed border-teal-600 dark:border-teal-500 p-6 rounded-3xl flex flex-col justify-between text-center items-center hover:bg-teal-50 dark:hover:bg-teal-950/60 transition"
          >
            <div>
              <div className="icon-box w-16 h-16 rounded-2xl bg-teal-600 text-white flex items-center justify-center mb-4 mx-auto shadow-sm">
                <Phone className="h-8 w-8" />
              </div>
              <h3 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white mb-2">
                {t.preferPhoneBooking}
              </h3>
              <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-sm md:text-base">
                {t.phoneBookingDesc}
              </p>
            </div>
            
            <div className="mt-6 w-full space-y-2">
              <a 
                href="tel:1800123456" 
                id="callTollFreeSupportLink"
                className="w-full py-3.5 bg-teal-700 hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500 text-white font-extrabold rounded-2xl shadow transition flex items-center justify-center gap-2 text-base cursor-pointer"
              >
                <PhoneOutgoing className="h-5 w-5" /> {t.tollFreeCallSupport}
              </a>
              <button
                type="button"
                id="requestCallbackBtn"
                onClick={() => {
                  setCallSupportContext('Phone Assistance');
                  setIsCallSupportOpen(true);
                }}
                className="w-full py-2.5 bg-white dark:bg-slate-850 border-2 border-teal-300 dark:border-teal-700 text-teal-800 dark:text-teal-200 font-bold rounded-2xl hover:bg-teal-100 dark:hover:bg-slate-800 transition text-sm flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Headphones className="h-4 w-4" /> {t.requestCallback}
              </button>
            </div>
          </div>
        </div>

        {/* Reassurance & Senior Safety Guarantees */}
        <section className="mt-16 bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-6 md:p-10 shadow-xs transition-colors">
          <div className="max-w-3xl mb-8">
            <span className="text-xs font-black uppercase tracking-wider text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/80 px-3 py-1 rounded-full border border-teal-200 dark:border-teal-800">
              {t.promiseBadge}
            </span>
            <h3 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white mt-2">
              {t.promiseTitle}
            </h3>
            <p className="text-slate-600 dark:text-slate-400 text-sm md:text-base mt-1">
              {t.promiseSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="w-12 h-12 rounded-xl bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300 flex items-center justify-center">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h4 className="text-lg font-black text-slate-900 dark:text-white">{t.bgCheckTitle}</h4>
              <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.bgCheckDesc}
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 flex items-center justify-center">
                <HeartHandshake className="h-6 w-6" />
              </div>
              <h4 className="text-lg font-black text-slate-900 dark:text-white">{t.whatsappUpdatesTitle}</h4>
              <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.whatsappUpdatesDesc}
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
                <Sparkles className="h-6 w-6" />
              </div>
              <h4 className="text-lg font-black text-slate-900 dark:text-white">{t.noContractTitle}</h4>
              <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.noContractDesc}
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Emergency SOS Banner (Shifted from top to the end of the website) */}
      <EmergencySOSBanner
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        cityName={selectedCity}
      />

      {/* Footer */}
      <footer className="bg-slate-900 dark:bg-slate-950 text-slate-300 dark:text-slate-400 py-10 pb-28 md:pb-10 border-t-2 border-slate-800 dark:border-slate-850">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <span className="text-2xl font-black text-white">
              Kin<span className="text-teal-400">Care</span>
            </span>
            <p className="text-xs text-slate-400">
              {t.footerSub}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold text-slate-300 dark:text-slate-400">
            <button 
              onClick={() => setIsEmergencyOpen(true)} 
              className="text-red-400 hover:text-red-300 underline font-black cursor-pointer"
            >
              {t.sosCallAmbulance}
            </button>
            <span>•</span>
            <button 
              onClick={() => {
                setCallSupportContext('Support');
                setIsCallSupportOpen(true);
              }}
              className="hover:text-white cursor-pointer"
            >
              {t.tollFreeCallSupport} 1800-123-4567
            </button>
            <span>•</span>
            <button 
              onClick={() => setIsBookingsOpen(true)}
              className="hover:text-white cursor-pointer"
            >
              {t.myVisits} ({bookings.length})
            </button>
          </div>

          <p className="text-xs text-slate-400 text-center">
            © {new Date().getFullYear()} KinCare Inc. {t.copyright}
          </p>
        </div>
      </footer>

      {/* Mobile Bottom Navigation Bar (Phone-First Life-Saving Controls) */}
      <MobileBottomNav
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenBookings={() => setIsBookingsOpen(true)}
        onOpenCallHelp={() => {
          setCallSupportContext('Mobile Helpline');
          setIsCallSupportOpen(true);
        }}
        onOpenProfile={handleOpenProfileInNewTab}
        bookingsCount={bookings.length}
      />

      {/* Accessible Booking Modal */}
      <BookingModal
        service={bookingService}
        isOpen={Boolean(bookingService)}
        onClose={() => setBookingService(null)}
        onBookingSuccess={handleBookingSuccess}
        currentCity={selectedCity}
      />

      {/* Emergency SOS Modal */}
      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        cityName={selectedCity}
      />

      {/* Bookings Drawer */}
      <BookingsDrawer
        isOpen={isBookingsOpen}
        onClose={() => setIsBookingsOpen(false)}
        bookings={bookings}
        onCancelBooking={handleCancelBooking}
      />

      {/* Call Support / Callback Modal */}
      <CallSupportModal
        isOpen={isCallSupportOpen}
        onClose={() => setIsCallSupportOpen(false)}
        serviceTitle={callSupportContext}
      />

      {/* Indian Languages Selector Modal */}
      <LanguageModal />

      {/* Secure Authentication Modal (Sign In / Register) */}
      <AuthModal />

      {/* User Account & Emergency Contacts Profile Modal */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onOpenBookings={() => {
          setIsProfileOpen(false);
          setIsBookingsOpen(true);
        }}
        bookingsCount={bookings.length}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <LanguageProvider>
          <KinCareApp />
        </LanguageProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

