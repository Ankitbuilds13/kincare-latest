import React from 'react';
import { 
  X, 
  Settings, 
  Languages, 
  MapPin, 
  Sun, 
  Moon, 
  ZoomIn, 
  ZoomOut, 
  Volume2, 
  VolumeX, 
  Calendar, 
  User, 
  ChevronRight, 
  LogOut, 
  Phone, 
  Check,
  AlertTriangle,
  PhoneCall,
  ExternalLink
} from 'lucide-react';
import { CITIES } from '../data/servicesData';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCity: string;
  onCityChange: (city: string) => void;
  isLargeFont: boolean;
  onToggleFontSize: () => void;
  isSpeaking: boolean;
  onToggleReadAloud: () => void;
  onOpenBookings: () => void;
  onOpenProfile: () => void;
  bookingsCount: number;
  onOpenEmergency?: () => void;
}

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  onClose,
  selectedCity,
  onCityChange,
  isLargeFont,
  onToggleFontSize,
  isSpeaking,
  onToggleReadAloud,
  onOpenBookings,
  onOpenProfile,
  bookingsCount,
  onOpenEmergency,
}) => {
  const { currentLanguage, openLanguageModal, t, availableLanguages, setLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user, isAuthenticated, openAuthModal, logout } = useAuth();

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 overflow-hidden animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="settingsDrawerTitle"
    >
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer Container */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white dark:bg-slate-900 shadow-2xl flex flex-col border-l-2 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 transition-colors">
          
          {/* 1. Header */}
          <div className="p-5 sm:p-6 border-b-2 border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-850">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-teal-600 text-white rounded-2xl shadow-md">
                <Settings className="h-6 w-6 animate-spin-slow" />
              </div>
              <div>
                <h2 id="settingsDrawerTitle" className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white">
                  {t.settings || 'Preferences & Settings'}
                </h2>
                <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                  Manage care preferences, account & accessibility
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              id="closeSettingsBtn"
              type="button"
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition cursor-pointer active:scale-95"
              aria-label="Close Settings Drawer"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* 2. Scrollable Body with All Accumulated Functions */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">

            {/* 👤 FUNCTION 1: PROFILE & USER ACCOUNT */}
            <div className="rounded-3xl border-2 border-teal-200 dark:border-teal-900/60 bg-teal-50/70 dark:bg-teal-950/40 p-4 sm:p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-black uppercase tracking-wider text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                  <User className="h-4 w-4" /> Account & Profile
                </span>
                {isAuthenticated && (
                  <span className="text-[10px] bg-teal-200/80 dark:bg-teal-900 text-teal-900 dark:text-teal-200 px-2 py-0.5 rounded-full font-black">
                    Signed In
                  </span>
                )}
              </div>

              {isAuthenticated && user ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white font-black text-lg flex items-center justify-center shadow-md flex-shrink-0">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="font-black text-slate-900 dark:text-white text-base truncate">
                        {user.name}
                      </h3>
                      <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 truncate">
                        {user.phone} • {user.role === 'senior_individual' ? 'Senior Individual' : 'Family Caregiver'}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <a
                      href="?view=profile"
                      target="_blank"
                      rel="noopener noreferrer"
                      id="drawerManageProfileBtn"
                      onClick={() => {
                        onClose();
                      }}
                      className="w-full py-2.5 px-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition cursor-pointer no-underline"
                      title="Open full profile in a new tab"
                    >
                      <span>View Profile</span>
                      <ExternalLink className="h-3.5 w-3.5 flex-shrink-0" />
                    </a>

                    <button
                      type="button"
                      id="drawerLogoutBtn"
                      onClick={logout}
                      className="w-full py-2.5 px-3 rounded-2xl bg-white dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-red-950/40 text-slate-700 hover:text-red-600 dark:text-slate-300 dark:hover:text-red-400 border border-slate-300 dark:border-slate-700 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 active:scale-95 transition cursor-pointer"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                      <span>Log Out</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 leading-relaxed">
                    Sign in to save medical profiles, track care visits, and store emergency contacts for swift booking.
                  </p>
                  <button
                    type="button"
                    id="drawerSignInBtn"
                    onClick={() => {
                      onClose();
                      openAuthModal('login');
                    }}
                    className="w-full py-3 px-4 rounded-2xl bg-teal-700 hover:bg-teal-800 text-white font-black text-sm flex items-center justify-center gap-2 shadow-md active:scale-95 transition cursor-pointer"
                  >
                    <User className="h-4 w-4" />
                    <span>Sign In or Register</span>
                  </button>
                </div>
              )}
            </div>

            {/* 🗓️ FUNCTION 2: MY VISITS & CARE BOOKINGS */}
            <div className="rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-4 sm:p-5 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Calendar className="h-4 w-4 text-teal-600 dark:text-teal-400" /> Care Schedule
                </span>
                <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                  {bookingsCount} {bookingsCount === 1 ? 'Visit' : 'Visits'}
                </span>
              </div>

              <div className="flex items-center justify-between gap-3 mt-3">
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-sm sm:text-base">
                    {t.myVisits}
                  </h3>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    {bookingsCount > 0 
                      ? `${bookingsCount} upcoming visit${bookingsCount > 1 ? 's' : ''} scheduled`
                      : 'No upcoming visits scheduled'}
                  </p>
                </div>

                <button
                  type="button"
                  id="drawerOpenBookingsBtn"
                  onClick={() => {
                    onClose();
                    onOpenBookings();
                  }}
                  className="py-2.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 dark:bg-teal-600 dark:hover:bg-teal-500 text-white font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-sm active:scale-95 transition cursor-pointer flex-shrink-0"
                >
                  <span>View Visits</span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* 📍 FUNCTION 3: LOCATION / CITY SELECTION */}
            <div className="rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-4 sm:p-5 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-teal-600 dark:text-teal-400" /> Care City / Location
                </span>
                <span className="text-[10px] font-bold text-teal-700 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 px-2 py-0.5 rounded-md border border-teal-200 dark:border-teal-800">
                  Doorstep Service
                </span>
              </div>

              <div className="mt-2">
                <label htmlFor="settingsCitySelect" className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
                  Select your current city for local verified nurses & ambulance availability:
                </label>
                <div className="relative">
                  <select
                    id="settingsCitySelect"
                    value={selectedCity}
                    onChange={(e) => onCityChange(e.target.value)}
                    className="w-full py-3 px-4 pr-10 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-black text-slate-900 dark:text-white text-sm sm:text-base outline-none focus:border-teal-600 dark:focus:border-teal-400 transition cursor-pointer appearance-none"
                  >
                    {CITIES.map((city) => (
                      <option key={city} value={city} className="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-bold">
                        {city}
                      </option>
                    ))}
                  </select>
                  <MapPin className="absolute right-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-teal-600 dark:text-teal-400 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* 🌐 FUNCTION 4: LANGUAGE CHANGE */}
            <div className="rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-4 sm:p-5 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Languages className="h-4 w-4 text-teal-600 dark:text-teal-400" /> Interface Language
                </span>
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400">
                  12+ Indian Languages
                </span>
              </div>

              <div className="mt-2 space-y-3">
                <div className="flex items-center justify-between p-3 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900/60">
                  <div>
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block">
                      Current Language
                    </span>
                    <span className="text-base font-black text-teal-950 dark:text-teal-200">
                      {currentLanguage.nativeName} ({currentLanguage.name})
                    </span>
                  </div>

                  <button
                    type="button"
                    id="settingsOpenLangModalBtn"
                    onClick={() => {
                      onClose();
                      openLanguageModal();
                    }}
                    className="py-2 px-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-black text-xs shadow-xs active:scale-95 transition cursor-pointer flex items-center gap-1"
                  >
                    <span>All Languages</span>
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>

                {/* Quick 4 popular Indian Languages Pills */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {availableLanguages.slice(0, 4).map((lang) => {
                    const isSelected = currentLanguage.code === lang.code;
                    return (
                      <button
                        key={lang.code}
                        type="button"
                        onClick={() => setLanguage(lang.code)}
                        className={`py-2 px-3 rounded-xl font-black text-xs flex items-center justify-between border-2 transition cursor-pointer active:scale-95 ${
                          isSelected
                            ? 'bg-teal-600 text-white border-teal-700 shadow-sm'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                        }`}
                      >
                        <span>{lang.nativeName}</span>
                        {isSelected && <Check className="h-3.5 w-3.5" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* 🌓 FUNCTION 5: DARK MODE / LIGHT MODE */}
            <div className="rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-4 sm:p-5 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  {theme === 'dark' ? <Moon className="h-4 w-4 text-amber-400" /> : <Sun className="h-4 w-4 text-amber-500" />} 
                  Theme & Appearance
                </span>
                <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                  {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  id="settingsLightModeBtn"
                  onClick={() => {
                    if (theme === 'dark') toggleTheme();
                  }}
                  className={`py-3 px-3.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 border-2 transition cursor-pointer active:scale-95 ${
                    theme === 'light'
                      ? 'bg-amber-100 border-amber-500 text-amber-950 shadow-md ring-2 ring-amber-400/40'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <Sun className="h-4 w-4 text-amber-600" />
                  <span>Light Mode</span>
                </button>

                <button
                  type="button"
                  id="settingsDarkModeBtn"
                  onClick={() => {
                    if (theme === 'light') toggleTheme();
                  }}
                  className={`py-3 px-3.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 border-2 transition cursor-pointer active:scale-95 ${
                    theme === 'dark'
                      ? 'bg-slate-950 border-amber-400 text-amber-300 shadow-md ring-2 ring-amber-400/30'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <Moon className="h-4 w-4 text-amber-400" />
                  <span>Dark Mode</span>
                </button>
              </div>
            </div>

            {/* 🔍 FUNCTION 6: FONT SIZE (SENIOR LARGE FONT MODE) */}
            <div className="rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-4 sm:p-5 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <ZoomIn className="h-4 w-4 text-teal-600 dark:text-teal-400" /> Senior Accessibility Font
                </span>
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                  isLargeFont 
                    ? 'bg-amber-300 text-amber-950 font-black' 
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}>
                  {isLargeFont ? 'Enlarged A+' : 'Standard A'}
                </span>
              </div>

              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-3 leading-relaxed">
                Enlarges interface text, buttons, and badges to ensure maximum legibility for senior eyes.
              </p>

              <button
                type="button"
                id="settingsFontToggleBtn"
                onClick={onToggleFontSize}
                className={`w-full py-3 px-4 rounded-2xl font-black text-sm flex items-center justify-between border-2 transition cursor-pointer active:scale-95 ${
                  isLargeFont
                    ? 'bg-amber-300 border-amber-500 text-amber-950 shadow-md'
                    : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-750'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {isLargeFont ? <ZoomOut className="h-5 w-5" /> : <ZoomIn className="h-5 w-5" />}
                  <span>{isLargeFont ? 'Switch to Standard Size' : 'Switch to Senior Large Font (A+)'}</span>
                </div>
                <span className="text-xs font-black underline">
                  {isLargeFont ? 'Active' : 'Turn On'}
                </span>
              </button>
            </div>

            {/* 🔊 FUNCTION 7: LISTEN (VOICE READ-ALOUD ASSISTANT) */}
            <div className="rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-4 sm:p-5 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Volume2 className="h-4 w-4 text-teal-600 dark:text-teal-400" /> Voice Read-Aloud
                </span>
                {isSpeaking && (
                  <span className="text-[10px] font-black bg-teal-600 text-white px-2 py-0.5 rounded-full animate-pulse">
                    Speaking Now
                  </span>
                )}
              </div>

              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-3 leading-relaxed">
                Reads the core emergency helpline, services, and instructions aloud in your selected language at a comfortable pace.
              </p>

              <button
                type="button"
                id="settingsVoiceReaderBtn"
                onClick={onToggleReadAloud}
                className={`w-full py-3 px-4 rounded-2xl font-black text-sm flex items-center justify-between border-2 transition cursor-pointer active:scale-95 ${
                  isSpeaking
                    ? 'bg-teal-600 border-teal-700 text-white shadow-md animate-pulse'
                    : 'bg-teal-50 dark:bg-teal-950/60 border-teal-300 dark:border-teal-800 text-teal-950 dark:text-teal-200 hover:bg-teal-100 dark:hover:bg-teal-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {isSpeaking ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                  <span>{isSpeaking ? t.stopAudio : t.listenAudio}</span>
                </div>
                <span className="text-xs font-black">
                  {isSpeaking ? 'Stop' : 'Listen'}
                </span>
              </button>
            </div>

            {/* Emergency SOS Quick Option */}
            {onOpenEmergency && (
              <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/40 border-2 border-red-300 dark:border-red-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-red-600 text-white rounded-xl animate-pulse">
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-red-900 dark:text-red-200 block">
                      Emergency Ambulance SOS
                    </span>
                    <span className="text-xs font-bold text-red-700 dark:text-red-300">
                      Call 108 / 112 (Free)
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenEmergency();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs shadow-xs transition active:scale-95 cursor-pointer flex items-center gap-1"
                >
                  <PhoneCall className="h-3.5 w-3.5" />
                  <span>Open SOS</span>
                </button>
              </div>
            )}

            {/* Helpline Notice */}
            <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-teal-600 text-white rounded-xl">
                  <Phone className="h-4 w-4" />
                </div>
                <div>
                  <span className="text-xs font-black text-slate-800 dark:text-slate-200 block">
                    Toll-Free Helpline
                  </span>
                  <span className="text-xs font-bold text-teal-700 dark:text-teal-400">
                    1800-123-4567 (24x7)
                  </span>
                </div>
              </div>
              <a 
                href="tel:18001234567"
                className="px-3 py-1.5 rounded-xl bg-teal-600 text-white font-black text-xs shadow-xs hover:bg-teal-700 transition"
              >
                Call
              </a>
            </div>

          </div>

          {/* 3. Footer */}
          <div className="p-4 sm:p-5 border-t-2 border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              KinCare Senior Citizen Care
            </span>
            <button
              type="button"
              onClick={onClose}
              className="py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white font-black text-xs transition cursor-pointer"
            >
              Done
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
