import React from 'react';
import { AlertTriangle, PhoneCall, ShieldAlert, HeartHandshake, Phone } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface EmergencySOSBannerProps {
  onOpenEmergency: () => void;
  cityName: string;
}

export const EmergencySOSBanner: React.FC<EmergencySOSBannerProps> = ({
  onOpenEmergency,
  cityName,
}) => {
  const { t } = useLanguage();

  return (
    <aside
      id="urgentSosSection"
      aria-label="Emergency Ambulance and Crisis Rescue"
      className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white shadow-2xl border-t-4 border-yellow-400 py-6 sm:py-8 px-4 sm:px-6 relative overflow-hidden"
    >
      {/* Background visual motif */}
      <div 
        className="absolute -right-12 -bottom-12 opacity-10 pointer-events-none text-white select-none"
        aria-hidden="true"
      >
        <ShieldAlert className="w-64 h-64" />
      </div>

      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-6 relative z-10">
        
        {/* Left: Emergency Status & Message */}
        <div className="flex items-start sm:items-center gap-4 text-center sm:text-left">
          <div className="p-3 sm:p-4 bg-white/20 backdrop-blur-sm rounded-3xl flex-shrink-0 animate-pulse border border-white/30">
            <AlertTriangle className="h-8 w-8 sm:h-10 sm:w-10 text-yellow-300" />
          </div>
          <div>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
              <span className="bg-yellow-400 text-red-950 font-black text-xs uppercase px-2.5 py-0.5 rounded-full tracking-wider">
                Emergency 24x7
              </span>
              <span className="text-xs font-bold text-red-100 flex items-center gap-1">
                <HeartHandshake className="h-3.5 w-3.5" /> Direct ICU Dispatch in {cityName}
              </span>
            </div>
            <h2 className="font-black text-xl sm:text-2xl md:text-3xl text-white tracking-tight leading-tight">
              {t.sosBarText}
            </h2>
            <p className="text-xs sm:text-sm text-red-100 font-semibold max-w-2xl mt-1">
              Free priority ambulance, rapid paramedic dispatch, and instant caregiver alerts. One-tap direct access.
            </p>
          </div>
        </div>

        {/* Right: Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto flex-shrink-0">
          {/* Main Ambulance Call Action */}
          <button
            id="emergencySosEndBtn"
            type="button"
            onClick={onOpenEmergency}
            className="w-full sm:w-auto bg-white hover:bg-yellow-100 text-red-600 font-black px-6 sm:px-8 py-3.5 sm:py-4 rounded-2xl text-base sm:text-lg flex items-center justify-center gap-2.5 shadow-2xl transition active:scale-95 cursor-pointer ring-4 ring-white/30 group"
          >
            <PhoneCall className="h-6 w-6 text-red-600 group-hover:scale-110 transition flex-shrink-0 animate-pulse" />
            <span>{t.sosCallAmbulance}</span>
          </button>

          {/* Secondary Direct Dial Helpline */}
          <a
            href="tel:108"
            id="quickDial108Btn"
            className="w-full sm:w-auto bg-red-800/80 hover:bg-red-800 text-white font-bold px-5 py-3.5 sm:py-4 rounded-2xl text-sm sm:text-base flex items-center justify-center gap-2 border border-red-400/40 transition active:scale-95 cursor-pointer"
          >
            <Phone className="h-5 w-5 text-yellow-300 flex-shrink-0" />
            <span>Dial 108</span>
          </a>
        </div>

      </div>
    </aside>
  );
};
