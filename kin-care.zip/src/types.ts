export type ServiceCategory = 
  | 'all' 
  | 'nursing' 
  | 'attendant' 
  | 'diagnostics' 
  | 'pharmacy' 
  | 'physio' 
  | 'doctor';

export interface CareService {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  category: ServiceCategory;
  priceFormatted: string;
  basePrice: number;
  badge: string;
  tagline: string;
  icon: 'stethoscope' | 'hand-heart' | 'activity' | 'pill' | 'person-standing' | 'phone' | 'video' | 'shield';
  accentColor: 'teal' | 'blue' | 'purple' | 'amber' | 'emerald' | 'rose';
  highlights: string[];
  slotsAvailable: string[];
}

export interface Booking {
  id: string;
  serviceId: string;
  serviceTitle: string;
  patientName: string;
  patientAge: number;
  timeSlot: string;
  visitDate: string;
  address: string;
  phone: string;
  notes?: string;
  status: 'assigned' | 'en-route' | 'in-progress' | 'completed';
  caregiverName: string;
  caregiverRole: string;
  caregiverPhone: string;
  caregiverRating: number;
  amount: number;
  discountApplied: number;
  createdAt: string;
}

export interface EmergencyContact {
  name: string;
  relation: string;
  phone: string;
}

export type UserRole = 'family_caregiver' | 'senior_individual' | 'healthcare_guardian';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  preferredCity?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  address?: string;
  createdAt: string;
}

export interface StoredUserRecord extends UserProfile {
  saltHex: string;
  passwordHashHex: string;
}

export interface AuthSession {
  user: UserProfile;
  token: string;
  expiresAt: number;
}

