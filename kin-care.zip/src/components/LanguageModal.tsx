import React, { useState } from 'react';
import { Languages, Check, X, Search, Sparkles } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const LanguageModal: React.FC = () => {
  const { 
    currentLanguage, 
    setLanguage, 
    isLanguageModalOpen, 
    closeLanguageModal, 
    availableLanguages,
    t 
  } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');

  if (!isLanguageModalOpen) return null;

  const filteredLanguages = availableLanguages.filter(lang => {
    const q = searchQuery.toLowerCase().trim();
    return (
      lang.name.toLowerCase().includes(q) ||
      lang.nativeName.toLowerCase().includes(q) ||
      lang.region.toLowerCase().includes(q)
    );
  });

  const handleSelect = (code: string) => {
    setLanguage(code);
    closeLanguageModal();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="languageModalTitle"
    >
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden border-2 border-slate-200 animate-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="bg-linear-to-r from-teal-800 to-slate-900 text-white p-4 sm:p-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-teal-500/20 border border-teal-400/40 p-2.5 rounded-2xl text-teal-300">
              <Languages className="h-6 w-6" />
            </div>
            <div>
              <h2 id="languageModalTitle" className="text-xl sm:text-2xl font-black tracking-tight">
                {t.languagesOfIndia}
              </h2>
              <p className="text-xs sm:text-sm text-teal-200 font-medium">
                Select your preferred language for Kin Care
              </p>
            </div>
          </div>
          <button
            onClick={closeLanguageModal}
            id="closeLanguageModalBtn"
            className="text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 p-2 rounded-full transition cursor-pointer"
            aria-label="Close language selector"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-200">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              id="languageSearchInput"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchLanguage}
              className="w-full pl-10 pr-4 py-2.5 text-sm sm:text-base rounded-xl border-2 border-slate-300 bg-white font-medium text-slate-900 focus:outline-none focus:border-teal-600 focus:ring-2 focus:ring-teal-100 transition"
              autoFocus
            />
          </div>
        </div>

        {/* Language Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 divide-y divide-slate-100">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
            {filteredLanguages.map((lang) => {
              const isSelected = lang.code === currentLanguage.code;
              return (
                <button
                  key={lang.code}
                  id={`selectLang_${lang.code}`}
                  onClick={() => handleSelect(lang.code)}
                  className={`flex items-center justify-between p-3.5 sm:p-4 rounded-2xl text-left border-2 transition cursor-pointer ${
                    isSelected 
                      ? 'bg-teal-50/80 border-teal-600 shadow-xs ring-2 ring-teal-500/20' 
                      : 'bg-white border-slate-200 hover:border-teal-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex flex-col pr-2">
                    <span className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                      {lang.nativeName}
                    </span>
                    <span className="text-xs sm:text-sm font-semibold text-slate-600">
                      {lang.name}
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5 font-medium">
                      {lang.region}
                    </span>
                  </div>

                  <div className="flex-shrink-0 ml-2">
                    {isSelected ? (
                      <div className="h-7 w-7 rounded-full bg-teal-600 text-white flex items-center justify-center shadow-xs">
                        <Check className="h-4 w-4 stroke-[3]" />
                      </div>
                    ) : (
                      <div className="h-7 w-7 rounded-full border-2 border-slate-200 flex items-center justify-center text-transparent">
                        <Check className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {filteredLanguages.length === 0 && (
            <div className="py-12 text-center text-slate-500">
              <p className="font-semibold text-base">No language matched "{searchQuery}"</p>
              <button
                onClick={() => setSearchQuery('')}
                className="mt-2 text-sm text-teal-600 font-bold hover:underline"
              >
                Show all Indian languages
              </button>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
          <div className="flex items-center gap-1.5 font-medium text-slate-600">
            <Sparkles className="h-4 w-4 text-amber-500" />
            <span>Includes 12 official regional Indian languages + English</span>
          </div>
          <button
            onClick={closeLanguageModal}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs sm:text-sm transition cursor-pointer ml-auto"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
