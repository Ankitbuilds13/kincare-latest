import React, { useState, useEffect } from 'react';
import { 
  HeartPulse, 
  Phone,
  Settings
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { SettingsDrawer } from './SettingsDrawer';

interface NavbarProps {
  selectedCity: string;
  onCityChange: (city: string) => void;
  onOpenEmergency: () => void;
  onOpenBookings: () => void;
  onOpenCallHelp: () => void;
  onOpenProfile: () => void;
  bookingsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  selectedCity,
  onCityChange,
  onOpenEmergency,
  onOpenBookings,
  onOpenCallHelp,
  onOpenProfile,
  bookingsCount,
}) => {
  const [isLargeFont, setIsLargeFont] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { currentLanguage, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user, isAuthenticated } = useAuth();

  const toggleFontSize = () => {
    const htmlEl = document.documentElement;
    const nextState = !isLargeFont;
    setIsLargeFont(nextState);
    if (nextState) {
      htmlEl.classList.add('enlarged-font');
    } else {
      htmlEl.classList.remove('enlarged-font');
    }
  };

  const handleReadAloud = () => {
    if (!('speechSynthesis' in window)) {
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToRead = `${t.tagline}. ${t.heroHeading} ${t.heroSubheading}. ${t.sosBarText} ${t.sosCallAmbulance}.`;
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = currentLanguage.speechCode;
    utterance.rate = 0.85; // Slower and clear for elderly listeners
    utterance.pitch = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  return (
    <>
      {/* Main Header / Navigation */}
      <header className="bg-white dark:bg-slate-900 border-b-2 border-slate-200 dark:border-slate-800 sticky top-0 z-40 shadow-xs transition-colors">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2.5 sm:py-3.5 flex items-center justify-between gap-3">
          
          {/* Brand Logo */}
          <a href="#" className="flex items-center gap-2 sm:gap-3 group focus:outline-none flex-shrink-0">
            <div className="bg-teal-600 text-white p-2 sm:p-2.5 rounded-2xl shadow group-hover:bg-teal-700 transition">
              <HeartPulse className="h-6 w-6 sm:h-7 sm:w-7" />
            </div>
            <div>
              <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white">
                Kin<span className="text-teal-600 dark:text-teal-400">Care</span>
              </span>
              <span className="hidden md:block text-xs font-bold text-slate-500 dark:text-slate-400 -mt-1 tracking-wide">
                {t.tagline}
              </span>
            </div>
          </a>

          {/* Top Right Controls: 24x7 Helpline + Accumulated Settings Icon */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick 24x7 Helpline */}
            <button
              id="topHelplineNavBtn"
              type="button"
              onClick={onOpenCallHelp}
              className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-teal-50 dark:bg-teal-950/60 hover:bg-teal-100 dark:hover:bg-teal-900/60 text-teal-900 dark:text-teal-200 border-2 border-teal-300 dark:border-teal-700 font-bold text-xs sm:text-sm transition cursor-pointer active:scale-95"
              title="24x7 Senior Helpline"
            >
              <Phone className="h-4 w-4 text-teal-700 dark:text-teal-400 flex-shrink-0" />
              <span className="hidden sm:inline font-black">{t.callHelpline || 'Helpline'}</span>
            </button>

            {/* ⭐ ACCUMULATED SETTINGS ICON (Top Right of Website) */}
            <button
              id="settingsNavBtn"
              type="button"
              onClick={() => setIsSettingsOpen(true)}
              aria-label="Open Settings, Preferences, Language, Location, Theme, Font, Visits, and Profile"
              className="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-2xl bg-slate-100 hover:bg-teal-50 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-100 border-2 border-slate-300 dark:border-slate-700 hover:border-teal-500 dark:hover:border-teal-500 font-black text-xs sm:text-sm transition shadow-xs cursor-pointer active:scale-95 group relative"
              title="Settings (Language, Location, Dark Mode, Font Size, Audio, Visits & Profile)"
            >
              <Settings className="h-5 w-5 text-teal-600 dark:text-teal-400 group-hover:rotate-90 transition-transform duration-300 flex-shrink-0" />
              <span className="font-black tracking-tight">{t.settings || 'Settings'}</span>

              {/* Badges: Scheduled Visits counter or User Initials */}
              {bookingsCount > 0 ? (
                <span className="bg-teal-600 text-white font-black text-[10px] px-1.5 py-0.5 rounded-full flex items-center justify-center border border-white dark:border-slate-900">
                  {bookingsCount}
                </span>
              ) : isAuthenticated && user ? (
                <span className="w-5 h-5 rounded-full bg-teal-600 text-white font-black text-[10px] flex items-center justify-center border border-white dark:border-slate-900">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              ) : null}
            </button>
          </div>

        </div>
      </header>

      {/* 3. Settings Drawer Accumulating All 7 Functions */}
      <SettingsDrawer
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        selectedCity={selectedCity}
        onCityChange={onCityChange}
        isLargeFont={isLargeFont}
        onToggleFontSize={toggleFontSize}
        isSpeaking={isSpeaking}
        onToggleReadAloud={handleReadAloud}
        onOpenBookings={onOpenBookings}
        onOpenProfile={onOpenProfile}
        bookingsCount={bookingsCount}
        onOpenEmergency={onOpenEmergency}
      />
    </>
  );
};
