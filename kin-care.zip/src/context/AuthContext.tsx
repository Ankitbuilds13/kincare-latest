import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, StoredUserRecord, AuthSession, UserRole } from '../types';
import { hashPassword, verifyPassword, generateSessionToken } from '../utils/crypto';

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'signup';
  openAuthModal: (mode?: 'login' | 'signup') => void;
  closeAuthModal: () => void;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  signup: (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role?: UserRole;
  }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>;
}

const USERS_STORAGE_KEY = 'kincare_registered_users_v1';
const SESSION_STORAGE_KEY = 'kincare_auth_session_v1';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');

  // Load registered users from localStorage
  const getStoredUsers = (): StoredUserRecord[] => {
    try {
      const data = localStorage.getItem(USERS_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  };

  // Save registered users to localStorage
  const saveStoredUsers = (users: StoredUserRecord[]) => {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (err) {
      console.error('Failed to save users securely to storage', err);
    }
  };

  // Initialize session and pre-seed demo account if needed
  useEffect(() => {
    const initAuth = async () => {
      try {
        let users = getStoredUsers();

        // If no users exist, securely seed a friendly demo user
        if (users.length === 0) {
          const demoCredentials = await hashPassword('Password@123');
          const demoUser: StoredUserRecord = {
            id: 'usr_demo_8821',
            name: 'Ananya Sharma',
            email: 'demo@kincare.in',
            phone: '+91 98765 43210',
            role: 'family_caregiver',
            preferredCity: 'Delhi NCR',
            emergencyContactName: 'Dr. Ramesh Sharma (Father)',
            emergencyContactPhone: '+91 98111 22334',
            address: 'B-402, Green Park Avenue, South Delhi',
            createdAt: new Date().toISOString(),
            saltHex: demoCredentials.saltHex,
            passwordHashHex: demoCredentials.hashHex,
          };
          users = [demoUser];
          saveStoredUsers(users);
        }

        // Check active session
        const sessionRaw = localStorage.getItem(SESSION_STORAGE_KEY);
        if (sessionRaw) {
          const session: AuthSession = JSON.parse(sessionRaw);
          // Check expiration
          if (session.expiresAt > Date.now()) {
            // Verify user still exists in stored users
            const existing = users.find((u) => u.id === session.user.id);
            if (existing) {
              const { saltHex: _s, passwordHashHex: _p, ...sanitized } = existing;
              setUser(sanitized);
            } else {
              localStorage.removeItem(SESSION_STORAGE_KEY);
            }
          } else {
            // Expired
            localStorage.removeItem(SESSION_STORAGE_KEY);
          }
        }
      } catch (err) {
        console.error('Error initializing authentication:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();
  }, []);

  const openAuthModal = (mode: 'login' | 'signup' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const login = async (
    email: string,
    password: string,
    rememberMe = true
  ): Promise<{ success: boolean; error?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    const users = getStoredUsers();
    const foundUser = users.find((u) => u.email.toLowerCase() === normalizedEmail);

    if (!foundUser) {
      return { success: false, error: 'No account found with this email address.' };
    }

    try {
      const isMatch = await verifyPassword(
        password,
        foundUser.saltHex,
        foundUser.passwordHashHex
      );

      if (!isMatch) {
        return { success: false, error: 'Incorrect password. Please try again.' };
      }

      // Sanitize user profile for session
      const { saltHex: _s, passwordHashHex: _p, ...sanitizedUser } = foundUser;
      setUser(sanitizedUser);

      const sessionDuration = rememberMe ? 14 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
      const session: AuthSession = {
        user: sanitizedUser,
        token: generateSessionToken(),
        expiresAt: Date.now() + sessionDuration,
      };

      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
      setIsAuthModalOpen(false);
      return { success: true };
    } catch {
      return { success: false, error: 'Failed to verify credentials. Please try again.' };
    }
  };

  const signup = async ({
    name,
    email,
    password,
    phone,
    role = 'family_caregiver',
  }: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role?: UserRole;
  }): Promise<{ success: boolean; error?: string }> => {
    const normalizedEmail = email.trim().toLowerCase();
    const users = getStoredUsers();

    if (users.some((u) => u.email.toLowerCase() === normalizedEmail)) {
      return {
        success: false,
        error: 'An account with this email is already registered. Please log in instead.',
      };
    }

    if (password.length < 6) {
      return {
        success: false,
        error: 'Password must be at least 6 characters long.',
      };
    }

    try {
      // Securely hash the password with PBKDF2
      const { saltHex, hashHex } = await hashPassword(password);

      const newUser: StoredUserRecord = {
        id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        name: name.trim(),
        email: normalizedEmail,
        phone: phone.trim(),
        role,
        createdAt: new Date().toISOString(),
        saltHex,
        passwordHashHex: hashHex,
      };

      const updatedUsers = [...users, newUser];
      saveStoredUsers(updatedUsers);

      // Auto login after sign up
      const { saltHex: _s, passwordHashHex: _p, ...sanitizedUser } = newUser;
      setUser(sanitizedUser);

      const session: AuthSession = {
        user: sanitizedUser,
        token: generateSessionToken(),
        expiresAt: Date.now() + 14 * 24 * 60 * 60 * 1000,
      };
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));

      setIsAuthModalOpen(false);
      return { success: true };
    } catch {
      return {
        success: false,
        error: 'Failed to create secure account. Please try again.',
      };
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(SESSION_STORAGE_KEY);
  };

  const updateProfile = async (
    updates: Partial<UserProfile>
  ): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Not authenticated' };

    const users = getStoredUsers();
    const userIndex = users.findIndex((u) => u.id === user.id);

    if (userIndex === -1) {
      return { success: false, error: 'User record not found.' };
    }

    const updatedUserRecord: StoredUserRecord = {
      ...users[userIndex],
      ...updates,
      id: user.id, // Immutable ID
      email: user.email, // Immutable Email for safety
    };

    users[userIndex] = updatedUserRecord;
    saveStoredUsers(users);

    const { saltHex: _s, passwordHashHex: _p, ...sanitizedUser } = updatedUserRecord;
    setUser(sanitizedUser);

    // Update active session
    const sessionRaw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (sessionRaw) {
      const session: AuthSession = JSON.parse(sessionRaw);
      session.user = sanitizedUser;
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    }

    return { success: true };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        isAuthModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
        login,
        signup,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
